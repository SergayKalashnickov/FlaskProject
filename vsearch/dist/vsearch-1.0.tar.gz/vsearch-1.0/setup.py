from setuptools import setup

setup(
     name='vsearch',
     version='1.0',
     description='Test my test',
     author='HF python 2e',
     author_email='hfpy2e@gmail.com',
     url='headfirstlabs.com',
     py_modules=['vsearch'],
)